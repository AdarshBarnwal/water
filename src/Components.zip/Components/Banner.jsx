import './Banner.css'

function Banner() {
  return (
    <div className='banner'>
        <img className='banner-img' src="https://waterjetpurifier.com/waterjetimage/4.jpg" alt="" />
    </div>
  )
}

export default Banner;